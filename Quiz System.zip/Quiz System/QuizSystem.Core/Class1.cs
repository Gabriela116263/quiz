﻿namespace QuizSystem.Core
{
    public class Class1
    {

    }
}
