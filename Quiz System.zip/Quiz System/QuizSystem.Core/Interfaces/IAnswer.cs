﻿namespace QuizSystem.Core.Interfaces
{
    /// <summary>
    /// Interfejs reprezentujący odpowiedź
    /// </summary>
    public interface IAnswer
    {
        int Id { get; set; }
        string Text { get; set; }
        bool IsCorrect { get; set; }
        int QuestionId { get; set; }

        bool Validate();
    }
}