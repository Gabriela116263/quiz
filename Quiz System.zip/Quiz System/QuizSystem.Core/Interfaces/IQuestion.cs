﻿using QuizSystem.Core.Models;
using System.Collections.Generic;

namespace QuizSystem.Core.Interfaces
{
    /// <summary>
    /// Interfejs reprezentujący pytanie
    /// </summary>
    public interface IQuestion
    {
        int Id { get; set; }
        string Text { get; set; }
        int Points { get; set; }
        int QuizId { get; set; }
        List<Answer> Answers { get; set; }

        void AddAnswer(Answer answer);
        void RemoveAnswer(Answer answer);
        Answer? GetCorrectAnswer();
        bool HasCorrectAnswer();
        bool Validate();
    }
}