﻿using QuizSystem.Core.Models;
using System;
using System.Collections.Generic;

namespace QuizSystem.Core.Interfaces
{
    /// <summary>
    /// Interfejs reprezentujący quiz
    /// </summary>
    public interface IQuiz
    {
        int Id { get; set; }
        string Title { get; set; }
        string Description { get; set; }
        DateTime CreatedDate { get; set; }
        string Category { get; set; }
        int TimeLimit { get; set; }
        List<Question> Questions { get; set; }

        void AddQuestion(Question question);
        void RemoveQuestion(Question question);
        int GetTotalPoints();
        int GetQuestionCount();
        bool Validate();
    }
}