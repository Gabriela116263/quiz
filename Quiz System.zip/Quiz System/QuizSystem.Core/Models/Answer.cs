﻿using QuizSystem.Core.Interfaces;

namespace QuizSystem.Core.Models
{
    /// <summary>
    /// Reprezentuje odpowiedź na pytanie w quizie
    /// </summary>
    public class Answer : IAnswer
    {
        public int Id { get; set; }
        public string Text { get; set; } = string.Empty;
        public bool IsCorrect { get; set; }
        public int QuestionId { get; set; }

        // Navigation property
        public Question? Question { get; set; }

        public Answer()
        {
        }

        public Answer(string text, bool isCorrect)
        {
            Text = text;
            IsCorrect = isCorrect;
        }

        public bool Validate()
        {
            return !string.IsNullOrWhiteSpace(Text);
        }

        public override string ToString()
        {
            return $"{Text} {(IsCorrect ? "✓" : "")}";
        }
    }
}