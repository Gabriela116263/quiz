﻿using QuizSystem.Core.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace QuizSystem.Core.Models
{
    /// <summary>
    /// Reprezentuje pytanie w quizie
    /// </summary>
    public class Question : IQuestion
    {
        public int Id { get; set; }
        public string Text { get; set; } = string.Empty;
        public int Points { get; set; } = 1;
        public int QuizId { get; set; }

        // Navigation properties
        public Quiz? Quiz { get; set; }
        public List<Answer> Answers { get; set; } = new List<Answer>();

        public Question()
        {
        }

        public Question(string text, int points = 1)
        {
            Text = text;
            Points = points;
        }

        public void AddAnswer(Answer answer)
        {
            if (answer != null && answer.Validate())
            {
                Answers.Add(answer);
                answer.Question = this;
            }
        }

        public void RemoveAnswer(Answer answer)
        {
            if (answer != null)
            {
                Answers.Remove(answer);
            }
        }

        public Answer? GetCorrectAnswer()
        {
            return Answers.FirstOrDefault(a => a.IsCorrect);
        }

        public bool HasCorrectAnswer()
        {
            return Answers.Any(a => a.IsCorrect);
        }

        public bool Validate()
        {
            return !string.IsNullOrWhiteSpace(Text)
                && Answers.Count >= 2
                && HasCorrectAnswer()
                && Points > 0;
        }

        public override string ToString()
        {
            return $"{Text} ({Points} pkt)";
        }
    }
}