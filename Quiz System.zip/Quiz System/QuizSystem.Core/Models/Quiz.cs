﻿using QuizSystem.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace QuizSystem.Core.Models
{
    /// <summary>
    /// Reprezentuje quiz zawierający pytania
    /// </summary>
    public class Quiz : IQuiz
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public string Category { get; set; } = "Ogólne";
        public int TimeLimit { get; set; } = 0; // w minutach, 0 = bez limitu

        // Navigation property
        public List<Question> Questions { get; set; } = new List<Question>();

        public Quiz()
        {
        }

        public Quiz(string title, string description, string category = "Ogólne")
        {
            Title = title;
            Description = description;
            Category = category;
            CreatedDate = DateTime.Now;
        }

        public void AddQuestion(Question question)
        {
            if (question != null && question.Validate())
            {
                Questions.Add(question);
                question.Quiz = this;
            }
        }

        public void RemoveQuestion(Question question)
        {
            if (question != null)
            {
                Questions.Remove(question);
            }
        }

        public int GetTotalPoints()
        {
            return Questions.Sum(q => q.Points);
        }

        public int GetQuestionCount()
        {
            return Questions.Count;
        }

        public string TotalPointsDisplay => GetTotalPoints().ToString();

        public bool Validate()
        {
            return !string.IsNullOrWhiteSpace(Title)
                && Questions.Count > 0
                && Questions.All(q => q.Validate());
        }

        public override string ToString()
        {
            return $"{Title} - {Questions.Count} pytań ({GetTotalPoints()} pkt)";
        }
    }
}