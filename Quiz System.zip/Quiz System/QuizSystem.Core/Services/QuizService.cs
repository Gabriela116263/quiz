﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace QuizSystem.Core.Services
{
    /// <summary>
    /// Generyczna klasa serwisu do zarządzania kolekcjami danych
    /// </summary>
    public class GenericDataManager<T> where T : class
    {
        private List<T> _items = new List<T>();

        public void Add(T item)
        {
            if (item != null)
            {
                _items.Add(item);
            }
        }

        public void Remove(T item)
        {
            if (item != null)
            {
                _items.Remove(item);
            }
        }

        public List<T> GetAll()
        {
            return new List<T>(_items);
        }

        public void Clear()
        {
            _items.Clear();
        }

        public int Count => _items.Count;

        public T? Find(Predicate<T> predicate)
        {
            return _items.FirstOrDefault(item => predicate(item));
        }

        public List<T> FindAll(Predicate<T> predicate)
        {
            return _items.Where(item => predicate(item)).ToList();
        }
    }

    /// <summary>
    /// Serwis do walidacji i operacji na quizach
    /// </summary>
    public class QuizService
    {
        public bool ValidateQuizStructure<TQuiz, TQuestion, TAnswer>(
            TQuiz quiz,
            List<TQuestion> questions,
            List<TAnswer> answers)
            where TQuiz : class
            where TQuestion : class
            where TAnswer : class
        {
            return quiz != null && questions != null && answers != null
                && questions.Count > 0 && answers.Count > 0;
        }

        public Dictionary<string, int> CalculateStatistics<T>(
            List<T> items,
            Func<T, string> keySelector,
            Func<T, int> valueSelector)
        {
            return items
                .GroupBy(keySelector)
                .ToDictionary(g => g.Key, g => g.Sum(valueSelector));
        }
    }
}