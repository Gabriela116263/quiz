﻿namespace QuizSystem.Data
{
    public class Class1
    {

    }
}
