﻿using Microsoft.EntityFrameworkCore;
using QuizSystem.Core.Models;

namespace QuizSystem.Data.Context
{
    /// <summary>
    /// Kontekst bazy danych Entity Framework Core
    /// </summary>
    public class QuizDbContext : DbContext
    {
        public DbSet<Quiz> Quizzes { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Answer> Answers { get; set; }

        public QuizDbContext(DbContextOptions<QuizDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Konfiguracja relacji Quiz -> Questions
            modelBuilder.Entity<Quiz>()
                .HasMany(q => q.Questions)
                .WithOne(qu => qu.Quiz)
                .HasForeignKey(qu => qu.QuizId)
                .OnDelete(DeleteBehavior.Cascade);

            // Konfiguracja relacji Question -> Answers
            modelBuilder.Entity<Question>()
                .HasMany(q => q.Answers)
                .WithOne(a => a.Question)
                .HasForeignKey(a => a.QuestionId)
                .OnDelete(DeleteBehavior.Cascade);

            // Konfiguracja właściwości
            modelBuilder.Entity<Quiz>()
                .Property(q => q.Title)
                .IsRequired()
                .HasMaxLength(200);

            modelBuilder.Entity<Quiz>()
                .Property(q => q.Category)
                .HasMaxLength(100);

            modelBuilder.Entity<Question>()
                .Property(q => q.Text)
                .IsRequired()
                .HasMaxLength(500);

            modelBuilder.Entity<Answer>()
                .Property(a => a.Text)
                .IsRequired()
                .HasMaxLength(300);

            // Indeksy dla lepszej wydajności
            modelBuilder.Entity<Quiz>()
                .HasIndex(q => q.Category);

            modelBuilder.Entity<Quiz>()
                .HasIndex(q => q.CreatedDate);

            // Dane początkowe (opcjonalne)
            SeedData(modelBuilder);
        }

        private void SeedData(ModelBuilder modelBuilder)
        {
            // Przykładowy quiz
            modelBuilder.Entity<Quiz>().HasData(
                new Quiz
                {
                    Id = 1,
                    Title = "Quiz Programowania C#",
                    Description = "Podstawowe pytania o C#",
                    Category = "Programowanie",
                    CreatedDate = DateTime.Now,
                    TimeLimit = 10
                }
            );

            // Przykładowe pytania
            modelBuilder.Entity<Question>().HasData(
                new Question
                {
                    Id = 1,
                    QuizId = 1,
                    Text = "Co oznacza skrót OOP?",
                    Points = 1
                },
                new Question
                {
                    Id = 2,
                    QuizId = 1,
                    Text = "Który język jest kompilowany?",
                    Points = 1
                }
            );

            // Przykładowe odpowiedzi
            modelBuilder.Entity<Answer>().HasData(
                new Answer { Id = 1, QuestionId = 1, Text = "Object Oriented Programming", IsCorrect = true },
                new Answer { Id = 2, QuestionId = 1, Text = "Online Office Platform", IsCorrect = false },
                new Answer { Id = 3, QuestionId = 1, Text = "Operating Object Protocol", IsCorrect = false },
                new Answer { Id = 4, QuestionId = 2, Text = "JavaScript", IsCorrect = false },
                new Answer { Id = 5, QuestionId = 2, Text = "C#", IsCorrect = true },
                new Answer { Id = 6, QuestionId = 2, Text = "Python", IsCorrect = false }
            );
        }
    }
}