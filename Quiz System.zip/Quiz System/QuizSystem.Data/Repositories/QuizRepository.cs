﻿using Microsoft.EntityFrameworkCore;
using QuizSystem.Core.Models;
using QuizSystem.Data.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace QuizSystem.Data.Repositories
{
    /// <summary>
    /// Repozytorium implementujące operacje CRUD dla quizów
    /// </summary>
    public class QuizRepository : IRepository<Quiz>
    {
        private readonly QuizDbContext _context;

        public QuizRepository(QuizDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<Quiz?> GetByIdAsync(int id)
        {
            return await _context.Quizzes
                .Include(q => q.Questions)
                .ThenInclude(qu => qu.Answers)
                .FirstOrDefaultAsync(q => q.Id == id);
        }

        public async Task<IEnumerable<Quiz>> GetAllAsync()
        {
            return await _context.Quizzes
                .Include(q => q.Questions)
                .ThenInclude(qu => qu.Answers)
                .ToListAsync();
        }

        public async Task<IEnumerable<Quiz>> FindAsync(Expression<Func<Quiz, bool>> predicate)
        {
            return await _context.Quizzes
                .Include(q => q.Questions)
                .ThenInclude(qu => qu.Answers)
                .Where(predicate)
                .ToListAsync();
        }

        public async Task<Quiz> AddAsync(Quiz entity)
        {
            _context.Quizzes.Add(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        public async Task UpdateAsync(Quiz entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var quiz = await _context.Quizzes.FindAsync(id);
            if (quiz != null)
            {
                _context.Quizzes.Remove(quiz);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.Quizzes.AnyAsync(q => q.Id == id);
        }

        public async Task<int> CountAsync()
        {
            return await _context.Quizzes.CountAsync();
        }

        // Dodatkowe metody specyficzne dla quizów wykorzystujące LINQ

        /// <summary>
        /// Wyszukuje quizy według kategorii
        /// </summary>
        public async Task<IEnumerable<Quiz>> GetByCategory(string category)
        {
            return await _context.Quizzes
                .Include(q => q.Questions)
                .Where(q => q.Category == category)
                .OrderBy(q => q.Title)
                .ToListAsync();
        }

        /// <summary>
        /// Wyszukuje quizy według fragmentu tytułu
        /// </summary>
        public async Task<IEnumerable<Quiz>> SearchByTitle(string searchTerm)
        {
            return await _context.Quizzes
                .Include(q => q.Questions)
                .Where(q => q.Title.Contains(searchTerm))
                .OrderByDescending(q => q.CreatedDate)
                .ToListAsync();
        }

        /// <summary>
        /// Pobiera wszystkie unikalne kategorie
        /// </summary>
        public async Task<IEnumerable<string>> GetAllCategories()
        {
            return await _context.Quizzes
                .Select(q => q.Category)
                .Distinct()
                .OrderBy(c => c)
                .ToListAsync();
        }

        /// <summary>
        /// Pobiera quizy utworzone w określonym zakresie dat
        /// </summary>
        public async Task<IEnumerable<Quiz>> GetByDateRange(DateTime startDate, DateTime endDate)
        {
            return await _context.Quizzes
                .Include(q => q.Questions)
                .Where(q => q.CreatedDate >= startDate && q.CreatedDate <= endDate)
                .OrderByDescending(q => q.CreatedDate)
                .ToListAsync();
        }

        /// <summary>
        /// Pobiera quizy z określoną minimalną liczbą pytań
        /// </summary>
        public async Task<IEnumerable<Quiz>> GetWithMinimumQuestions(int minQuestions)
        {
            return await _context.Quizzes
                .Include(q => q.Questions)
                .Where(q => q.Questions.Count >= minQuestions)
                .OrderBy(q => q.Title)
                .ToListAsync();
        }

        /// <summary>
        /// Pobiera statystyki quizów według kategorii
        /// </summary>
        public async Task<Dictionary<string, int>> GetQuizCountByCategory()
        {
            return await _context.Quizzes
                .GroupBy(q => q.Category)
                .Select(g => new { Category = g.Key, Count = g.Count() })
                .ToDictionaryAsync(x => x.Category, x => x.Count);
        }
    }
}