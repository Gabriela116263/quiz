﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using QuizSystem.Data.Context;
using QuizSystem.Data.Repositories;
using System;
using System.Windows;

namespace QuizSystem.WPF
{
    /// <summary>
    /// Logika interakcji dla App.xaml
    /// </summary>
    public partial class App : Application
    {
        private static ServiceProvider? _serviceProvider;

        public App()
        {
            var services = new ServiceCollection();
            ConfigureServices(services);
            _serviceProvider = services.BuildServiceProvider();
        }

        private void ConfigureServices(IServiceCollection services)
        {
            // Konfiguracja Entity Framework Core
            services.AddDbContext<QuizDbContext>(options =>
            {
                // Użyj SQL Server LocalDB
                options.UseSqlServer(
                    @"Server=(localdb)\mssqllocaldb;Database=QuizSystemDb;Trusted_Connection=True;TrustServerCertificate=True;");

                // Alternatywnie - SQLite (prostsze dla testów):
                // options.UseSqlite("Data Source=quizsystem.db");
            });

            // Rejestracja repozytoriów
            services.AddScoped<QuizRepository>();
        }

        protected override async void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Automatyczne utworzenie/aktualizacja bazy danych
            try
            {
                using var scope = _serviceProvider!.CreateScope();
                var context = scope.ServiceProvider.GetRequiredService<QuizDbContext>();
                await context.Database.MigrateAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Błąd inicjalizacji bazy danych:\n{ex.Message}\n\n" +
                    "Upewnij się, że SQL Server LocalDB jest zainstalowany lub zmień connection string w App.xaml.cs",
                    "Błąd bazy danych",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        public static T GetService<T>() where T : class
        {
            if (_serviceProvider == null)
                throw new InvalidOperationException("Service provider not initialized");

            return _serviceProvider.GetRequiredService<T>();
        }
    }
}