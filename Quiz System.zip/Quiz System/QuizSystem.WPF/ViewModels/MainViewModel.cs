﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace QuizSystem.WPF.ViewModels
{
    /// <summary>
    /// Bazowy ViewModel implementujący INotifyPropertyChanged
    /// </summary>
    public class BaseViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
        {
            if (Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }

    /// <summary>
    /// Główny ViewModel aplikacji
    /// </summary>
    public class MainViewModel : BaseViewModel
    {
        private object? _currentView;

        public object? CurrentView
        {
            get => _currentView;
            set => SetProperty(ref _currentView, value);
        }

        public MainViewModel()
        {
            // Domyślny widok to lista quizów
            CurrentView = new QuizListViewModel();
        }

        public void NavigateToQuizList()
        {
            CurrentView = new QuizListViewModel();
        }

        public void NavigateToQuizEditor(int? quizId = null)
        {
            CurrentView = new QuizEditorViewModel(quizId);
        }

        public void NavigateToQuizPlayer(int quizId)
        {
            CurrentView = new QuizPlayerViewModel(quizId);
        }
    }
}