﻿using QuizSystem.Core.Models;
using QuizSystem.Data.Repositories;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;

namespace QuizSystem.WPF.ViewModels
{
    /// <summary>
    /// ViewModel dla edytora quizów
    /// </summary>
    public class QuizEditorViewModel : BaseViewModel
    {
        private readonly QuizRepository _repository;
        private Quiz _currentQuiz;
        private Question? _selectedQuestion;
        private Answer? _selectedAnswer;

        public Quiz CurrentQuiz
        {
            get => _currentQuiz;
            set => SetProperty(ref _currentQuiz, value);
        }

        public Question? SelectedQuestion
        {
            get => _selectedQuestion;
            set => SetProperty(ref _selectedQuestion, value);
        }

        public Answer? SelectedAnswer
        {
            get => _selectedAnswer;
            set => SetProperty(ref _selectedAnswer, value);
        }

        public ICommand SaveQuizCommand { get; }
        public ICommand AddQuestionCommand { get; }
        public ICommand RemoveQuestionCommand { get; }
        public ICommand AddAnswerCommand { get; }
        public ICommand RemoveAnswerCommand { get; }

        public QuizEditorViewModel(int? quizId = null)
        {
            _repository = App.GetService<QuizRepository>();
            _currentQuiz = new Quiz();

            SaveQuizCommand = new RelayCommand(async () => await SaveQuizAsync());
            AddQuestionCommand = new RelayCommand(AddQuestion);
            RemoveQuestionCommand = new RelayCommand(RemoveQuestion, () => SelectedQuestion != null);
            AddAnswerCommand = new RelayCommand(AddAnswer, () => SelectedQuestion != null);
            RemoveAnswerCommand = new RelayCommand(RemoveAnswer, () => SelectedAnswer != null);

            if (quizId.HasValue)
            {
                _ = LoadQuizAsync(quizId.Value);
            }
            else
            {
                InitializeNewQuiz();
            }
        }

        private void InitializeNewQuiz()
        {
            CurrentQuiz = new Quiz
            {
                Title = "Nowy Quiz",
                Description = "Opis quizu",
                Category = "Ogólne",
                TimeLimit = 0
            };
        }

        private async Task LoadQuizAsync(int quizId)
        {
            try
            {
                var quiz = await _repository.GetByIdAsync(quizId);
                if (quiz != null)
                {
                    CurrentQuiz = quiz;
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"Błąd ładowania quizu: {ex.Message}",
                    "Błąd", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            }
        }

        private async Task SaveQuizAsync()
        {
            try
            {
                if (!CurrentQuiz.Validate())
                {
                    System.Windows.MessageBox.Show(
                        "Quiz jest nieprawidłowy. Upewnij się, że:\n" +
                        "- Ma tytuł\n" +
                        "- Ma co najmniej jedno pytanie\n" +
                        "- Każde pytanie ma co najmniej 2 odpowiedzi\n" +
                        "- Każde pytanie ma jedną poprawną odpowiedź",
                        "Walidacja",
                        System.Windows.MessageBoxButton.OK,
                        System.Windows.MessageBoxImage.Warning);
                    return;
                }

                if (CurrentQuiz.Id == 0)
                {
                    await _repository.AddAsync(CurrentQuiz);
                }
                else
                {
                    await _repository.UpdateAsync(CurrentQuiz);
                }

                System.Windows.MessageBox.Show("Quiz został zapisany pomyślnie!",
                    "Sukces", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"Błąd zapisywania quizu: {ex.Message}",
                    "Błąd", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            }
        }

        private void AddQuestion()
        {
            var question = new Question
            {
                Text = "Nowe pytanie",
                Points = 1
            };
            CurrentQuiz.AddQuestion(question);
            OnPropertyChanged(nameof(CurrentQuiz));
        }

        private void RemoveQuestion()
        {
            if (SelectedQuestion != null)
            {
                CurrentQuiz.RemoveQuestion(SelectedQuestion);
                SelectedQuestion = null;
                OnPropertyChanged(nameof(CurrentQuiz));
            }
        }

        private void AddAnswer()
        {
            if (SelectedQuestion != null)
            {
                var answer = new Answer
                {
                    Text = "Nowa odpowiedź",
                    IsCorrect = false
                };
                SelectedQuestion.AddAnswer(answer);
                OnPropertyChanged(nameof(SelectedQuestion));
            }
        }

        private void RemoveAnswer()
        {
            if (SelectedAnswer != null && SelectedQuestion != null)
            {
                SelectedQuestion.RemoveAnswer(SelectedAnswer);
                SelectedAnswer = null;
                OnPropertyChanged(nameof(SelectedQuestion));
            }
        }
    }
}