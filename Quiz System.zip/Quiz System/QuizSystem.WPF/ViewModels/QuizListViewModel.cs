﻿using QuizSystem.Core.Models;
using QuizSystem.Data.Repositories;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using System;

namespace QuizSystem.WPF.ViewModels
{
    /// <summary>
    /// ViewModel dla listy quizów z funkcjami LINQ
    /// </summary>
    public class QuizListViewModel : BaseViewModel
    {
        private readonly QuizRepository _repository;
        private ObservableCollection<Quiz> _quizzes;
        private string _searchText = string.Empty;
        private string _selectedCategory = "Wszystkie";
        private Quiz? _selectedQuiz;

        public ObservableCollection<Quiz> Quizzes
        {
            get => _quizzes;
            set => SetProperty(ref _quizzes, value);
        }

        public string SearchText
        {
            get => _searchText;
            set
            {
                if (SetProperty(ref _searchText, value))
                {
                    _ = FilterQuizzesAsync();
                }
            }
        }

        public string SelectedCategory
        {
            get => _selectedCategory;
            set
            {
                if (SetProperty(ref _selectedCategory, value))
                {
                    _ = FilterQuizzesAsync();
                }
            }
        }

        public Quiz? SelectedQuiz
        {
            get => _selectedQuiz;
            set => SetProperty(ref _selectedQuiz, value);
        }

        public ObservableCollection<string> Categories { get; set; }

        public ICommand LoadQuizzesCommand { get; }
        public ICommand DeleteQuizCommand { get; }
        public ICommand RefreshCommand { get; }

        public QuizListViewModel()
        {
            _repository = App.GetService<QuizRepository>();
            _quizzes = new ObservableCollection<Quiz>();
            Categories = new ObservableCollection<string> { "Wszystkie" };

            LoadQuizzesCommand = new RelayCommand(async () => await LoadQuizzesAsync());
            DeleteQuizCommand = new RelayCommand(async () => await DeleteQuizAsync(), () => SelectedQuiz != null);
            RefreshCommand = new RelayCommand(async () => await LoadQuizzesAsync());

            _ = LoadQuizzesAsync();
        }

        private async Task LoadQuizzesAsync()
        {
            try
            {
                var quizzes = await _repository.GetAllAsync();
                Quizzes = new ObservableCollection<Quiz>(quizzes);

                // Załaduj kategorie używając LINQ
                var categories = await _repository.GetAllCategories();
                Categories.Clear();
                Categories.Add("Wszystkie");
                foreach (var category in categories)
                {
                    Categories.Add(category);
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"Błąd ładowania quizów: {ex.Message}",
                    "Błąd", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            }
        }

        private async Task FilterQuizzesAsync()
        {
            try
            {
                var allQuizzes = await _repository.GetAllAsync();

                // Zastosuj filtry LINQ
                var filtered = allQuizzes.AsQueryable();

                if (!string.IsNullOrWhiteSpace(SearchText))
                {
                    filtered = filtered.Where(q =>
                        q.Title.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ||
                        q.Description.Contains(SearchText, StringComparison.OrdinalIgnoreCase));
                }

                if (SelectedCategory != "Wszystkie")
                {
                    filtered = filtered.Where(q => q.Category == SelectedCategory);
                }

                Quizzes = new ObservableCollection<Quiz>(filtered.OrderByDescending(q => q.CreatedDate));
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"Błąd filtrowania quizów: {ex.Message}",
                    "Błąd", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            }
        }

        private async Task DeleteQuizAsync()
        {
            if (SelectedQuiz == null) return;

            var result = System.Windows.MessageBox.Show(
                $"Czy na pewno chcesz usunąć quiz '{SelectedQuiz.Title}'?",
                "Potwierdzenie",
                System.Windows.MessageBoxButton.YesNo,
                System.Windows.MessageBoxImage.Question);

            if (result == System.Windows.MessageBoxResult.Yes)
            {
                try
                {
                    await _repository.DeleteAsync(SelectedQuiz.Id);
                    await LoadQuizzesAsync();
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show($"Błąd usuwania quizu: {ex.Message}",
                        "Błąd", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
                }
            }
        }
    }

    /// <summary>
    /// Prosta implementacja ICommand
    /// </summary>
    public class RelayCommand : ICommand
    {
        private readonly Action _execute;
        private readonly Func<bool>? _canExecute;

        public event EventHandler? CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }

        public RelayCommand(Action execute, Func<bool>? canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object? parameter) => _canExecute?.Invoke() ?? true;
        public void Execute(object? parameter) => _execute();
    }

    /// <summary>
    /// Generyczna implementacja ICommand
    /// </summary>
    public class RelayCommand<T> : ICommand
    {
        private readonly Action<T> _execute;
        private readonly Func<T, bool>? _canExecute;

        public event EventHandler? CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }

        public RelayCommand(Action<T> execute, Func<T, bool>? canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object? parameter)
        {
            if (parameter is T typedParameter)
                return _canExecute?.Invoke(typedParameter) ?? true;
            return false;
        }

        public void Execute(object? parameter)
        {
            if (parameter is T typedParameter)
                _execute(typedParameter);
        }
    }
}