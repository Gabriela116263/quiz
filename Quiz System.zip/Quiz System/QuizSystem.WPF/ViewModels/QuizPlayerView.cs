﻿using QuizSystem.Core.Models;
using QuizSystem.Data.Repositories;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;

namespace QuizSystem.WPF.ViewModels
{
    /// <summary>
    /// ViewModel dla rozwiązywania quizu
    /// </summary>
    public class QuizPlayerViewModel : BaseViewModel
    {
        private readonly QuizRepository _repository;
        private Quiz? _quiz;
        private Question? _currentQuestion;
        private int _currentQuestionIndex;
        private int _score;
        private int _correctAnswers;
        private bool _isQuizCompleted;
        private Answer? _selectedAnswer;

        public Quiz? Quiz
        {
            get => _quiz;
            set => SetProperty(ref _quiz, value);
        }

        public Question? CurrentQuestion
        {
            get => _currentQuestion;
            set => SetProperty(ref _currentQuestion, value);
        }

        public int CurrentQuestionIndex
        {
            get => _currentQuestionIndex;
            set => SetProperty(ref _currentQuestionIndex, value);
        }

        public int Score
        {
            get => _score;
            set => SetProperty(ref _score, value);
        }

        public int CorrectAnswers
        {
            get => _correctAnswers;
            set => SetProperty(ref _correctAnswers, value);
        }

        public bool IsQuizCompleted
        {
            get => _isQuizCompleted;
            set => SetProperty(ref _isQuizCompleted, value);
        }

        public Answer? SelectedAnswer
        {
            get => _selectedAnswer;
            set => SetProperty(ref _selectedAnswer, value);
        }

        public string Progress => Quiz != null
            ? $"Pytanie {CurrentQuestionIndex + 1} z {Quiz.Questions.Count}"
            : "";

        public string ScoreDisplay => $"Wynik: {Score} pkt";

        public ICommand SubmitAnswerCommand { get; }
        public ICommand NextQuestionCommand { get; }
        public ICommand RestartQuizCommand { get; }
        public ICommand SelectAnswerCommand { get; }

        public QuizPlayerViewModel(int quizId)
        {
            _repository = App.GetService<QuizRepository>();

            SubmitAnswerCommand = new RelayCommand(SubmitAnswer, () => SelectedAnswer != null);
            NextQuestionCommand = new RelayCommand(NextQuestion);
            RestartQuizCommand = new RelayCommand(RestartQuiz);
            SelectAnswerCommand = new RelayCommand<Answer>(answer => SelectedAnswer = answer);

            _ = LoadQuizAsync(quizId);
        }

        private async Task LoadQuizAsync(int quizId)
        {
            try
            {
                Quiz = await _repository.GetByIdAsync(quizId);
                if (Quiz != null && Quiz.Questions.Any())
                {
                    CurrentQuestionIndex = 0;
                    CurrentQuestion = Quiz.Questions[0];
                    Score = 0;
                    CorrectAnswers = 0;
                    IsQuizCompleted = false;
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"Błąd ładowania quizu: {ex.Message}",
                    "Błąd", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            }
        }

        private void SubmitAnswer()
        {
            if (SelectedAnswer == null || CurrentQuestion == null) return;

            if (SelectedAnswer.IsCorrect)
            {
                Score += CurrentQuestion.Points;
                CorrectAnswers++;
                System.Windows.MessageBox.Show("Poprawna odpowiedź! ✓",
                    "Wynik", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
            }
            else
            {
                var correctAnswer = CurrentQuestion.GetCorrectAnswer();
                System.Windows.MessageBox.Show(
                    $"Niepoprawna odpowiedź.\nPoprawna odpowiedź to: {correctAnswer?.Text}",
                    "Wynik", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
            }

            OnPropertyChanged(nameof(ScoreDisplay));
            NextQuestion();
        }

        private void NextQuestion()
        {
            if (Quiz == null) return;

            SelectedAnswer = null;
            CurrentQuestionIndex++;

            if (CurrentQuestionIndex < Quiz.Questions.Count)
            {
                CurrentQuestion = Quiz.Questions[CurrentQuestionIndex];
                OnPropertyChanged(nameof(Progress));
            }
            else
            {
                IsQuizCompleted = true;
                ShowFinalResults();
            }
        }

        private void ShowFinalResults()
        {
            if (Quiz == null) return;

            var totalPoints = Quiz.GetTotalPoints();
            var percentage = totalPoints > 0 ? (Score * 100.0 / totalPoints) : 0;

            System.Windows.MessageBox.Show(
                $"Quiz zakończony!\n\n" +
                $"Poprawne odpowiedzi: {CorrectAnswers}/{Quiz.Questions.Count}\n" +
                $"Wynik: {Score}/{totalPoints} punktów\n" +
                $"Procent: {percentage:F1}%",
                "Wyniki końcowe",
                System.Windows.MessageBoxButton.OK,
                System.Windows.MessageBoxImage.Information);
        }

        private void RestartQuiz()
        {
            if (Quiz == null) return;

            CurrentQuestionIndex = 0;
            CurrentQuestion = Quiz.Questions[0];
            Score = 0;
            CorrectAnswers = 0;
            IsQuizCompleted = false;
            SelectedAnswer = null;

            OnPropertyChanged(nameof(Progress));
            OnPropertyChanged(nameof(ScoreDisplay));
        }
    }
}