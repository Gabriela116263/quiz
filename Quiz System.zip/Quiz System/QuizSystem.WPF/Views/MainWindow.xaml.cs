﻿using System.Windows;

namespace QuizSystem.WPF.Views
{
    /// <summary>
    /// Logika interakcji dla MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ShowQuizList();
        }

        private void ShowQuizList()
        {
            MainContentControl.Content = new QuizListView();
            StatusText.Text = "Lista quizów";
        }

        private void ShowQuizList_Click(object sender, RoutedEventArgs e)
        {
            ShowQuizList();
        }

        private void CreateNewQuiz_Click(object sender, RoutedEventArgs e)
        {
            MainContentControl.Content = new QuizEditorView();
            StatusText.Text = "Edytor quizów - Nowy quiz";
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "System Quizów v1.0\n\n" +
                "Aplikacja do tworzenia i rozwiązywania quizów\n" +
                "Stworzona z użyciem WPF i Entity Framework Core\n\n" +
                "© 2024",
                "O programie",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}