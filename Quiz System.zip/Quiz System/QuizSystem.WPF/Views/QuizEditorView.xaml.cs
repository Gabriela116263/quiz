﻿using QuizSystem.WPF.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace QuizSystem.WPF.Views
{
    /// <summary>
    /// Logika interakcji dla QuizEditorView.xaml
    /// </summary>
    public partial class QuizEditorView : UserControl
    {
        public QuizEditorView(int? quizId = null)
        {
            InitializeComponent();
            DataContext = new QuizEditorViewModel(quizId);
        }

        private void BackToList_Click(object sender, RoutedEventArgs e)
        {
            var parent = Window.GetWindow(this) as MainWindow;
            if (parent != null)
            {
                parent.MainContentControl.Content = new QuizListView();
            }
        }
    }
}