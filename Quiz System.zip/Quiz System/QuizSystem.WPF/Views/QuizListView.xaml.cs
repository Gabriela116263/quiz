﻿using QuizSystem.Core.Models;
using QuizSystem.WPF.ViewModels;
using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace QuizSystem.WPF.Views
{
    /// <summary>
    /// Logika interakcji dla QuizListView.xaml
    /// </summary>
    public partial class QuizListView : UserControl
    {
        public QuizListView()
        {
            InitializeComponent();
            DataContext = new QuizListViewModel();
        }

        private void NewQuiz_Click(object sender, RoutedEventArgs e)
        {
            var parent = Window.GetWindow(this) as MainWindow;
            if (parent != null)
            {
                parent.MainContentControl.Content = new QuizEditorView();
            }
        }

        private void EditQuiz_Click(object sender, RoutedEventArgs e)
        {
            var viewModel = DataContext as QuizListViewModel;
            if (viewModel?.SelectedQuiz != null)
            {
                var parent = Window.GetWindow(this) as MainWindow;
                if (parent != null)
                {
                    parent.MainContentControl.Content = new QuizEditorView(viewModel.SelectedQuiz.Id);
                }
            }
        }

        private void PlayQuiz_Click(object sender, RoutedEventArgs e)
        {
            var viewModel = DataContext as QuizListViewModel;
            if (viewModel?.SelectedQuiz != null)
            {
                var parent = Window.GetWindow(this) as MainWindow;
                if (parent != null)
                {
                    parent.MainContentControl.Content = new QuizPlayerView(viewModel.SelectedQuiz.Id);
                }
            }
        }
    }
}