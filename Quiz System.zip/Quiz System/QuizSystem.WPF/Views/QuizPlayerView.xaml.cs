﻿using QuizSystem.WPF.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace QuizSystem.WPF.Views
{
    /// <summary>
    /// Logika interakcji dla QuizPlayerView.xaml
    /// </summary>
    public partial class QuizPlayerView : UserControl
    {
        public QuizPlayerView(int quizId)
        {
            InitializeComponent();
            DataContext = new QuizPlayerViewModel(quizId);
        }

        private void BackToList_Click(object sender, RoutedEventArgs e)
        {
            var parent = Window.GetWindow(this) as MainWindow;
            if (parent != null)
            {
                parent.MainContentControl.Content = new QuizListView();
            }
        }
    }
}